%% ========================= Initialization =========================
clear ; close all; clc

% Load Data
% The first two columns contains the X values and the third column
% contains the label (y).
data = load('ex2data2.txt');
X = data(:, [1, 2]); y = data(:, 3);


% Plot the data
plotData(X, y);
hold on;
legend('y = 1', 'y = 0')
hold off;


%% ================ Part 1: Add Polynomial Features =================
% Note that mapFeature also adds a column of ones for us, so the intercept
% term is handled
X = mapFeature(X(:,1), X(:,2));


%% ========== Part 2: Train Polynomial Logistic Regression ==========
% Train like a linear logistic regression
theta = zeros(size(X, 2), 1);
options = optimset('GradObj', 'on', 'MaxIter', 400);
theta = fminunc(@(t)(costFunction(t, X, y)), theta, options);

% Plot Boundary
plotDecisionBoundary(theta, X, y);
hold on;
legend('y = 1', 'y = 0', 'Decision boundary')
hold off;
