function [J, grad] = costFunction(theta, X, y)

    h = sigmoid(X * theta);
    J = sum(-y .* log(h) - (1-y) .* log(1-h));
    grad = X' * (h - y);

end
