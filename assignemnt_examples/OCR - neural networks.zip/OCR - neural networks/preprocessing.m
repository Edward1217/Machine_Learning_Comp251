cd 'C:\Users\hkamranh\Desktop\OCR - neural networks\training set'

files = [dir('*.png'); dir('*.jpg')];
m = length(files);
data = zeros(m , 101);

for i = 1:m
    filename = files(i).name;
    img = imread(filename);
    img = rgb2gray(img);
    img = imresize(img, [10 10]);
    img = img(:);
    img = [img' , mod(i-1, 5) + 1];
    data(i, :) = img;
end

cd 'C:\Users\hkamranh\Desktop\OCR - neural networks'
writematrix(data);
